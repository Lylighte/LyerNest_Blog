#include "exp_jumping_warnsdorff.cpp"
// #include "exp_jumping.cpp"

int main(){
    JumpingMain();
    return 0;
}