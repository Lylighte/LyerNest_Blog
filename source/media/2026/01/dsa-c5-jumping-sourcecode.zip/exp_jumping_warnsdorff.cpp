/*
Name:        exp_jumping_warnsdorff.cpp
Function:    Solve Knight's Tour problem using backtracking
Author:      Lylighte(Yuanda Li, PB24231833)
Version:     v25.11.21
ChangeLog:

# Nov 21, 2025
- Added a macrodefine for default chessboard size
- Changed the macrodefine for max chessboard size to 10+(now 64)
- Added JumpingSearchFirstSolution function skeleton
  - For every size > 5, only search out the first solution and write to file
- Add a timer to measure execution time
- Added limit on maximum search steps for HUGE boards

# Nov 14, 2025
- Create this file
- Completed basic implementation of Knight's Tour backtracking solution
- Added logging for function steps and solutions found
- Changed to Warnsdorff's heuristic for optimization
- Added file output for the first solution found
Todo:
- Visualize the chessboard and the knight's path
- Make some positions unreachable (obstacles)
*/

#ifndef JUMPING_CPP
#define JUMPING_CPP

#define CHESSBOARD_MAX_SIZE 64
#define CHESSBOARD_DEFAULT_SIZE 8
#define CHESSBOARD_OUTPUT_MAX_SIZE 6
#define FUNCTION_STEP_LOG_INTERVAL 1000000
#define SOLUTION_LOG_INTERVAL 1000
#define MAX_SEARCH_STEPS 50000000

#define KNIGHT_TOUR_FIRST_SOLUTION_FILE "knights_tour_first_solution.txt"

#include <iostream>
#include <iomanip>
#include <fstream>
#include <algorithm>
#include <string>

#include <chrono>
#include <ctime>

#include "exp_jumping_replay.cpp"

struct PosOnChessboard{
    char x;
    char y;
};

struct StepStatusElem{
    PosOnChessboard pos;
    char direction; // range 0..7
};

struct MoveOption {
    char dir;
    char onwardMoves;
};

bool MoveOptionCompare(const MoveOption& a, const MoveOption& b) {
    return a.onwardMoves < b.onwardMoves;
}

// Possible knight move directions
const PosOnChessboard moveDirections[8] = {
        {2, 1}, {1, 2}, {-1, 2}, {-2, 1},
        {-2, -1}, {-1, -2}, {1, -2}, {2, -1}
};

long long totalFunctionSteps = 0;
bool firstSolutionFound = false;
std::string firstSolutionFilename = "";

void InitChessboardSizes(short int& size)
{
    std::cout << "Enter the size of the chessboard (max " << CHESSBOARD_MAX_SIZE << "): ";
    std::string buffer;
    std::getline(std::cin, buffer);
    size = static_cast<short int>(std::stoi(buffer));
    if(size < 1 || size > CHESSBOARD_MAX_SIZE){
        std::cerr << "Invalid size, setting to default " << CHESSBOARD_DEFAULT_SIZE << "." << std::endl;
        size = CHESSBOARD_DEFAULT_SIZE;
    }
    std::cout << "Chessboard size set to " << size << "x" << size << "." << std::endl;
}

void InitChessboard(bool board[CHESSBOARD_MAX_SIZE][CHESSBOARD_MAX_SIZE], short int size)
{
    for(short int i = 0; i < size; ++i){
        for(short int j = 0; j < size; ++j){
            board[i][j] = 0;
        }
    }
}

void InitPos(PosOnChessboard &pos)
{
    std::cout << "Enter the initial position of the knight (e.g., 0 0 for top-left corner): ";
    std::string buffer;
    std::getline(std::cin, buffer);
    size_t spacePos = buffer.find(' ');
    pos.x = static_cast<char>(std::stoi(buffer.substr(0, spacePos)));
    pos.y = static_cast<char>(std::stoi(buffer.substr(spacePos + 1)));
    if(pos.x < 0 || pos.x >= CHESSBOARD_MAX_SIZE || pos.y < 0 || pos.y >= CHESSBOARD_MAX_SIZE){
        std::cerr << "Invalid position, setting to default (0,0)." << std::endl;
        pos.x = 0;
        pos.y = 0;
    }
    std::cout << "Initial position set to (" << static_cast<int>(pos.x) << ", " << static_cast<int>(pos.y) << ")." << std::endl;
}

void DrawChessboard(StepStatusElem Stack[], const short int size)
{
    short int stepBoard[CHESSBOARD_MAX_SIZE][CHESSBOARD_MAX_SIZE];
    for (short int i = 0; i < size; ++i){
        for (short int j = 0; j < size; ++j){
            stepBoard[i][j] = 0;
        }
    }
    short int stepCount = 1;
    
    for(short int i = 0; i < size * size; ++i){
        PosOnChessboard pos = Stack[i].pos;
        stepBoard[pos.x][pos.y] = stepCount;
        stepCount++;
    }

    for(short int i = 0; i < size; ++i){
        for(short int j = 0; j < size; ++j){
            if(stepBoard[i][j] != 0){
                std::cout << std::setw(6) << stepBoard[i][j] << " ";
            } else {
                std::cout << std::setw(6) << "." << " ";
            }
        }
        std::cout << std::endl;
    }
}

bool ValidPos(const PosOnChessboard& pos, const short int chessboardSize, const bool boardVisited[CHESSBOARD_MAX_SIZE][CHESSBOARD_MAX_SIZE])
{
    return (pos.x >= 0 && pos.x < chessboardSize &&
            pos.y >= 0 && pos.y < chessboardSize &&
            !boardVisited[pos.x][pos.y]);
}

void WriteFirstSolutionToFile(StepStatusElem stepStack[], const short int size)
{
    // filename: boardsize_(init_x_inity)_knights_tour_first_solution.txt
    // e.g. board_64_(0_8)_knights_tour_first_solution.txt
    /* format
    <size> as an interger
    <stepboard> as a size x size grid, each cell is either step number or '.' for unvisited
    */
    std::string initPosX = std::to_string(stepStack[0].pos.x);
    std::string initPosY = std::to_string(stepStack[0].pos.y);
    std::string filename = "board_" + std::to_string(size) + "_(" + initPosX + "_" + initPosY + ")_" + KNIGHT_TOUR_FIRST_SOLUTION_FILE;
    std::ofstream outFile(filename);
    if (!outFile) {
        std::cerr << "Error creating file: " << filename << std::endl;
        return;
    }
    short int stepBoard[CHESSBOARD_MAX_SIZE][CHESSBOARD_MAX_SIZE];
    for (short int i = 0; i < size; ++i){
        for (short int j = 0; j < size; ++j){
            stepBoard[i][j] = 0;
        }
    }
    short int stepCount = 1;
    for(short int i = 0; i < size * size; ++i){
        PosOnChessboard pos = stepStack[i].pos;
        stepBoard[pos.x][pos.y] = stepCount;
        stepCount++;
    }

    outFile << size << std::endl;
    for(short int i = 0; i < size; ++i){
        for(short int j = 0; j < size; ++j){
            if(stepBoard[i][j] != 0){
                outFile << std::setw(6) << stepBoard[i][j] << " ";
            } else {
                outFile << std::setw(6) << "." << " ";
            }
        }
        outFile << std::endl;
    }
    outFile.close();
    std::cout << "First solution written to file: " << filename << std::endl;
    firstSolutionFilename = filename;
}

// Search all possible knight's tours using Warnsdorff's heuristic
void JumpingSearch(StepStatusElem stepStack[], bool boardVisited[CHESSBOARD_MAX_SIZE][CHESSBOARD_MAX_SIZE], const short int chessboardSize, short int stepCount, long int& solutionCount)
{
    totalFunctionSteps++;
    if (totalFunctionSteps % FUNCTION_STEP_LOG_INTERVAL == 0){
        std::cout << "Function steps: " << totalFunctionSteps << ", Current depth: " << stepCount << ", Solutions found: " << solutionCount << std::endl;
    }
    if (stepCount == chessboardSize * chessboardSize){
        if (!firstSolutionFound) {
            WriteFirstSolutionToFile(stepStack, chessboardSize);
            firstSolutionFound = true;
        }
        solutionCount++;
        if (chessboardSize <= CHESSBOARD_OUTPUT_MAX_SIZE){
            // std::cout << "A complete tour is found(#" << solutionCount << "):" << std::endl;
            std::cout << "Solution #" << solutionCount << " found." << std::endl;
            if (solutionCount <= 10) {
                DrawChessboard(stepStack, chessboardSize);
            }
        } 
        else if (solutionCount % SOLUTION_LOG_INTERVAL == 0){
            // std::cout << "Solutions found: " << solutionCount << std::endl;
            std::cout << "Solution #" << solutionCount << " found." << std::endl;
        }
        return;
    }
    
    // using heuristic: Warnsdorff's rule
    PosOnChessboard currentPos = stepStack[stepCount - 1].pos;
    MoveOption moveOptions[8];
    for (char dir = 0; dir < 8; ++dir){
        PosOnChessboard nextPos;
        nextPos.x = currentPos.x + moveDirections[dir].x;
        nextPos.y = currentPos.y + moveDirections[dir].y;
        if(ValidPos(nextPos, chessboardSize, boardVisited)){
            // Count onward moves
            char onwardMoves = 0;
            for(char nextDir = 0; nextDir < 8; ++nextDir){
                PosOnChessboard onwardPos;
                onwardPos.x = nextPos.x + moveDirections[nextDir].x;
                onwardPos.y = nextPos.y + moveDirections[nextDir].y;
                if(ValidPos(onwardPos, chessboardSize, boardVisited) && !(onwardPos.x == currentPos.x && onwardPos.y == currentPos.y)){
                    onwardMoves++;
                }
            }
            moveOptions[dir] = {dir, onwardMoves};
        } else {
            moveOptions[dir] = {dir, 9}; // invalid move gets high count
        }
    }

    std::sort(moveOptions, moveOptions + 8, MoveOptionCompare);
    for(char i = 0; i < 8; ++i){
        if (moveOptions[i].onwardMoves == 9) {
            continue; // skip invalid moves
        }
        char dir = moveOptions[i].dir;
        PosOnChessboard nextPos;
        nextPos.x = currentPos.x + moveDirections[dir].x;
        nextPos.y = currentPos.y + moveDirections[dir].y;
        if (ValidPos(nextPos, chessboardSize, boardVisited)){
            stepStack[stepCount].pos = nextPos;
            stepStack[stepCount].direction = dir;
            boardVisited[nextPos.x][nextPos.y] = true;
            JumpingSearch(stepStack, boardVisited, chessboardSize, stepCount + 1, solutionCount);
            boardVisited[nextPos.x][nextPos.y] = false; // backtrack
        }
    }
}

// Search for the first knight's tour solution only, also using Warnsdorff's heuristic
void JumpingSearchFirstSolution(StepStatusElem stepStack[], bool boardVisited[CHESSBOARD_MAX_SIZE][CHESSBOARD_MAX_SIZE], const short int chessboardSize, short int stepCount, long int& solutionCount)
{
    totalFunctionSteps++;
    if (stepCount == chessboardSize * chessboardSize){
        if (!firstSolutionFound) {
            WriteFirstSolutionToFile(stepStack, chessboardSize);
            firstSolutionFound = true;
        }
        solutionCount++;
        return;
    }
    if (totalFunctionSteps % FUNCTION_STEP_LOG_INTERVAL == 0){
        std::cout << "Function steps: " << totalFunctionSteps << ", Current depth: " << stepCount << ", Solutions found: " << solutionCount << std::endl;
    }
    if (firstSolutionFound) {
        return; // already found the first solution
    }
    if (totalFunctionSteps >= MAX_SEARCH_STEPS) {
        // std::cout << "Reached maximum search steps limit (" << MAX_SEARCH_STEPS << "). Stopping search." << std::endl;
        return;
    }

    // using heuristic: Warnsdorff's rule
    PosOnChessboard currentPos = stepStack[stepCount - 1].pos;
    MoveOption moveOptions[8];
    for (char dir = 0; dir < 8; ++dir){
        PosOnChessboard nextPos;
        nextPos.x = currentPos.x + moveDirections[dir].x;
        nextPos.y = currentPos.y + moveDirections[dir].y;
        if(ValidPos(nextPos, chessboardSize, boardVisited)){
            // Count onward moves
            char onwardMoves = 0;
            for(char nextDir = 0; nextDir < 8; ++nextDir){
                PosOnChessboard onwardPos;
                onwardPos.x = nextPos.x + moveDirections[nextDir].x;
                onwardPos.y = nextPos.y + moveDirections[nextDir].y;
                if(ValidPos(onwardPos, chessboardSize, boardVisited) && !(onwardPos.x == currentPos.x && onwardPos.y == currentPos.y)){
                    onwardMoves++;
                }
            }
            moveOptions[dir] = {dir, onwardMoves};
        } else {
            moveOptions[dir] = {dir, 9}; // invalid move gets high count
        }
    }

    std::sort(moveOptions, moveOptions + 8, MoveOptionCompare);
    for(char i = 0; i < 8; ++i){
        if (moveOptions[i].onwardMoves == 9) {
            continue; // skip invalid moves
        }
        char dir = moveOptions[i].dir;
        PosOnChessboard nextPos;
        nextPos.x = currentPos.x + moveDirections[dir].x;
        nextPos.y = currentPos.y + moveDirections[dir].y;
        if (ValidPos(nextPos, chessboardSize, boardVisited)){
            stepStack[stepCount].pos = nextPos;
            stepStack[stepCount].direction = dir;
            boardVisited[nextPos.x][nextPos.y] = true;

            // if (!firstSolutionFound)
            JumpingSearchFirstSolution(stepStack, boardVisited, chessboardSize, stepCount + 1, solutionCount);
            
            boardVisited[nextPos.x][nextPos.y] = false; // backtrack
        }
    }
}

void JumpingMain()
{
    std::cout << "This is a placeholder for the Jumping (Knight's Tour) problem solver." << std::endl;
    bool boardVisited[CHESSBOARD_MAX_SIZE][CHESSBOARD_MAX_SIZE];
    StepStatusElem stepStack[CHESSBOARD_MAX_SIZE * CHESSBOARD_MAX_SIZE];

    short int chessboardSize = 8;
    PosOnChessboard initPos = {0, 0};
    InitChessboardSizes(chessboardSize);
    InitChessboard(boardVisited, chessboardSize);
    InitPos(initPos);

    // record program start time at dynamic initialization (before main)
    static const std::chrono::steady_clock::time_point programStartTime = std::chrono::steady_clock::now();

    stepStack[0].pos = initPos;
    stepStack[0].direction = 0;
    boardVisited[initPos.x][initPos.y] = true;

    long int solutionCount = 0;
    // JumpingSearch(stepStack, boardVisited, chessboardSize, 1, solutionCount);
    if (chessboardSize > 5) {
        JumpingSearchFirstSolution(stepStack, boardVisited, chessboardSize, 1, solutionCount);
    } else {
        JumpingSearch(stepStack, boardVisited, chessboardSize, 1, solutionCount);
    }

    if (chessboardSize > 5 && !firstSolutionFound) {
        std::cout << "No solution found within the maximum search steps limit (" << MAX_SEARCH_STEPS << ")." << std::endl;
    }
    std::cout << "Total solutions found: " << solutionCount << std::endl;
    // timer
    std::cout << "Total function steps: " << totalFunctionSteps << std::endl;

    // compute and print elapsed times
    {
        const auto programEndTime = std::chrono::steady_clock::now();
        const auto wallMs = std::chrono::duration_cast<std::chrono::milliseconds>(programEndTime - programStartTime).count();

        const std::clock_t cpuClock = std::clock();
        const double cpuSeconds = static_cast<double>(cpuClock) / static_cast<double>(CLOCKS_PER_SEC);

        std::cout << "Elapsed wall time: " << wallMs << " ms (" << (wallMs / 1000.0) << " s)" << std::endl;
        std::cout << "Elapsed CPU time:  " << cpuSeconds << " s" << std::endl;
    }
    std::cout << "----------------------" << std::endl;
    JumpingReplayMain(firstSolutionFilename);
    std::cout << "----------------------" << std::endl;
    std::cout << "Knight's Tour experiment finished. Press Enter to exit." << std::endl;
    getchar();
}

#endif // JUMPING_CPP