/*
Name:        exp_jumping.cpp
Function:    Solve Knight's Tour problem using backtracking
Author:      Lylighte(Yuanda Li, PB24231833)
Version:     v25.11.14
ChangeLog:

# Nov 14, 2025
- Create this file
- Completed basic implementation of Knight's Tour backtracking solution
*/

#ifndef JUMPING_CPP
#define JUMPING_CPP

#define CHESSBOARD_MAX_SIZE 8
#define FUNCTION_STEP_LOG_INTERVAL 10000000

#include <iostream>
#include <iomanip>
#include <string>

struct PosOnChessboard{
    char x;
    char y;
};

struct StepStatusElem{
    PosOnChessboard pos;
    char direction; // range 0..7
};

const PosOnChessboard moveDirections[8] = {
        {2, 1}, {1, 2}, {-1, 2}, {-2, 1},
        {-2, -1}, {-1, -2}, {1, -2}, {2, -1}
};

long long totalFunctionSteps = 0;

void InitChessboardSizes(short int& size)
{
    std::cout << "Enter the size of the chessboard (max " << CHESSBOARD_MAX_SIZE << "): ";
    std::string buffer;
    std::getline(std::cin, buffer);
    size = static_cast<short int>(std::stoi(buffer));
    if(size < 1 || size > CHESSBOARD_MAX_SIZE){
        std::cerr << "Invalid size, setting to default " << CHESSBOARD_MAX_SIZE << "." << std::endl;
        size = CHESSBOARD_MAX_SIZE;
    }
    std::cout << "Chessboard size set to " << size << "x" << size << "." << std::endl;
}

void InitChessboard(bool board[CHESSBOARD_MAX_SIZE][CHESSBOARD_MAX_SIZE], short int size)
{
    for(short int i = 0; i < size; ++i){
        for(short int j = 0; j < size; ++j){
            board[i][j] = 0;
        }
    }
}

void InitPos(PosOnChessboard &pos)
{
    std::cout << "Enter the initial position of the knight (e.g., 0 0 for top-left corner): ";
    std::string buffer;
    std::getline(std::cin, buffer);
    size_t spacePos = buffer.find(' ');
    pos.x = static_cast<char>(std::stoi(buffer.substr(0, spacePos)));
    pos.y = static_cast<char>(std::stoi(buffer.substr(spacePos + 1)));
    if(pos.x < 0 || pos.x >= CHESSBOARD_MAX_SIZE || pos.y < 0 || pos.y >= CHESSBOARD_MAX_SIZE){
        std::cerr << "Invalid position, setting to default (0,0)." << std::endl;
        pos.x = 0;
        pos.y = 0;
    }
    std::cout << "Initial position set to (" << static_cast<int>(pos.x) << ", " << static_cast<int>(pos.y) << ")." << std::endl;
}

void DrawChessboard(StepStatusElem Stack[], const short int size)
{
    short int stepBoard[CHESSBOARD_MAX_SIZE][CHESSBOARD_MAX_SIZE];
    for (short int i = 0; i < size; ++i){
        for (short int j = 0; j < size; ++j){
            stepBoard[i][j] = 0;
        }
    }
    short int stepCount = 1;
    
    for(short int i = 0; i < size * size; ++i){
        PosOnChessboard pos = Stack[i].pos;
        stepBoard[pos.x][pos.y] = stepCount;
        stepCount++;
    }

    for(short int i = 0; i < size; ++i){
        for(short int j = 0; j < size; ++j){
            if(stepBoard[i][j] != 0){
                std::cout << std::setw(4) << stepBoard[i][j] << " ";
            } else {
                std::cout << std::setw(4) << "." << " ";
            }
        }
        std::cout << std::endl;
    }
}

bool ValidPos(const PosOnChessboard& pos, const short int chessboardSize, const bool boardVisited[CHESSBOARD_MAX_SIZE][CHESSBOARD_MAX_SIZE])
{
    return (pos.x >= 0 && pos.x < chessboardSize &&
            pos.y >= 0 && pos.y < chessboardSize &&
            !boardVisited[pos.x][pos.y]);
}

void JumpingSearch(StepStatusElem stepStack[], bool boardVisited[CHESSBOARD_MAX_SIZE][CHESSBOARD_MAX_SIZE], const short int chessboardSize, short int stepCount, long int& solutionCount)
{
    totalFunctionSteps++;
    if (totalFunctionSteps % FUNCTION_STEP_LOG_INTERVAL == 0){
        std::cout << "Function steps: " << totalFunctionSteps << ", Current depth: " << stepCount << ", Solutions found: " << solutionCount << std::endl;
    }
    if (stepCount == chessboardSize * chessboardSize){
        std::cout << "A complete tour is found:" << std::endl;
        DrawChessboard(stepStack, chessboardSize);
        solutionCount++;
        return;
    }
    
    PosOnChessboard currentPos = stepStack[stepCount - 1].pos;
    for(char dir = 0; dir < 8; ++dir){
        PosOnChessboard nextPos;
        nextPos.x = currentPos.x + moveDirections[dir].x;
        nextPos.y = currentPos.y + moveDirections[dir].y;
        if (ValidPos(nextPos, chessboardSize, boardVisited)){
            stepStack[stepCount].pos = nextPos;
            stepStack[stepCount].direction = dir;
            boardVisited[nextPos.x][nextPos.y] = true;
            JumpingSearch(stepStack, boardVisited, chessboardSize, stepCount + 1, solutionCount);
            boardVisited[nextPos.x][nextPos.y] = false;
        }
    }
}

void JumpingMain()
{
    std::cout << "This is a placeholder for the Jumping (Knight's Tour) problem solver." << std::endl;
    bool boardVisited[CHESSBOARD_MAX_SIZE][CHESSBOARD_MAX_SIZE];
    StepStatusElem stepStack[CHESSBOARD_MAX_SIZE * CHESSBOARD_MAX_SIZE];

    short int chessboardSize = 8;
    PosOnChessboard initPos = {0, 0};
    InitChessboardSizes(chessboardSize);
    InitChessboard(boardVisited, chessboardSize);
    InitPos(initPos);

    stepStack[0].pos = initPos;
    stepStack[0].direction = 0;
    boardVisited[initPos.x][initPos.y] = true;

    long int solutionCount = 0;
    JumpingSearch(stepStack, boardVisited, chessboardSize, 1, solutionCount);
    std::cout << "Total solutions found: " << solutionCount << std::endl;
}

#endif // JUMPING_CPP