/*
Name:        exp_jumping_warnsdorff.cpp
Function:    Replay of Knight's Tour solution
Author:      Lylighte(Yuanda Li, PB24231833)
Version:     v25.11.21
ChangeLog:
# Nov 21, 2025
Detail:
Read the file such as "board_size_(posx_posy)_knights_tour_first_solution.txt", 
and replay the knight's tour solution step by step on console.
User can choose whether to autoplay or step through manually.
*/

#ifndef JUMPING_REPLAY_CPP
#define JUMPING_REPLAY_CPP

#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>

#include <chrono>
#include <thread>

#ifndef MAX_BOARD_SIZE
#define MAX_BOARD_SIZE 64
#endif
#ifndef MAX_REPLAY_SIZE
#define MAX_REPLAY_SIZE 12
#endif

void JumpingReplayMain(std::string filename)
{
    std::cout << "Replaying Knight's Tour solution from file: " << filename << std::endl;
    std::ifstream inFile(filename);
    if (!inFile) {
        std::cerr << "Error opening file: " << filename << std::endl;
        return;
    }
    short int size;
    inFile >> size;
    if (size <= 0) {
        std::cerr << "Invalid board size in file: " << size << std::endl;
        return;
    }
    if (size > MAX_REPLAY_SIZE) {
        std::cout << "Board size exceeds maximum replay size (" << MAX_REPLAY_SIZE << "): " << size << std::endl;
        return;
    }
    short int stepBoard[MAX_REPLAY_SIZE][MAX_REPLAY_SIZE];
    for (short int i = 0; i < size; ++i){
        for (short int j = 0; j < size; ++j){
            stepBoard[i][j] = 0;
            std::string cell;
            inFile >> cell;
            if (cell != ".") {
                stepBoard[i][j] = std::stoi(cell);
            }
        }
    }
    inFile.close();

    std::cout << "Board size: " << size << "x" << size << std::endl;
    std::cout << "Press Enter to step through each move, or type 'a' and Enter to autoplay." << std::endl;

    // Replay the moves
    // Given that board size is relatively small, we can just do a simple loop
    // Position that the knight has visited is marked by the step number, that the knight is currently on is marked by 'K', otherwise '.'
    short int currentStepBoard[MAX_REPLAY_SIZE][MAX_REPLAY_SIZE] = {0};
    bool autoplay = false;
    std::string command;
    
    {
        // read initial command to choose manual or autoplay
        std::getline(std::cin, command);
        if (command == "a") autoplay = true;

        const int totalSteps = size * size;
        for (short int step = 1; step <= totalSteps; ++step) {
            // find position for this step
            short int pi = -1, pj = -1;
            for (short int i = 0; i < size && pi == -1; ++i) {
                for (short int j = 0; j < size; ++j) {
                    if (stepBoard[i][j] == step) {
                        pi = i; pj = j;
                        break;
                    }
                }
            }
            if (pi == -1) {
                // step not present in input, skip
                continue;
            }

            // mark visited
            currentStepBoard[pi][pj] = step;

            // clear console (cross-platform)
        #ifdef _WIN32
            std::system("cls");
        #else
            std::cout << "\x1B[2J\x1B[H";
        #endif

            // header
            std::cout << "Replaying Knight's Tour (" << step << " / " << totalSteps << ")\n\n";

            // draw board
            for (short int i = 0; i < size; ++i) {
                for (short int j = 0; j < size; ++j) {
                    if (i == pi && j == pj) {
                        std::cout << std::setw(4) << 'K';
                    } else if (currentStepBoard[i][j] > 0) {
                        std::cout << std::setw(4) << currentStepBoard[i][j];
                    } else {
                        std::cout << std::setw(4) << '.';
                    }
                }
                std::cout << '\n';
            }
            std::cout << std::flush;

            // wait for next action
            if (autoplay) {
                std::this_thread::sleep_for(std::chrono::milliseconds(350));
            } else {
                // user can press Enter to step, 'a' + Enter to switch to autoplay, 'q' + Enter to quit
                std::getline(std::cin, command);
                if (command == "a") {
                    autoplay = true;
                } else if (command == "q") {
                    break;
                }
            }
        }

        // final state / pause before exit
        std::cout << "\nReplay finished. Press Enter to continue...";
        std::getline(std::cin, command);
    }
}

#endif